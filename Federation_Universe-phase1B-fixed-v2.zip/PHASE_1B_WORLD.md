# The Federation Universe — Phase 1B

Phase 1B adds the first original homebrew Star Trek environment: **Horizon Station**.

It seeds 12 connected station rooms and 6 persistent NPCs. The legacy TalesMUD room engine remains the realtime spatial layer, while Federation Universe metadata is attached to rooms for the future Quadrant → Sector → System → Station/Ship → Deck → Room hierarchy.

## Build

From `public/mud-client`:

```powershell
npm install
npm run build
```

The build produces `public/bundle.js` and copies the completed client to `pkg/webuiplay/dist`, which is the directory embedded by the Go server.

## Seed

From the repository root:

```powershell
go run .\cmd\seed_federation
```

The seed uses `talesmud.db` by default, matching the server's default. Set `SQLITE_PATH` to use another database.
