import { cp, mkdir, rm } from "node:fs/promises";
import { resolve } from "node:path";
const source=resolve("public"); const destination=resolve("../../pkg/webuiplay/dist");
await rm(destination,{recursive:true,force:true}); await mkdir(destination,{recursive:true}); await cp(source,destination,{recursive:true});
console.log(`Copied mud-client build to ${destination}`);
