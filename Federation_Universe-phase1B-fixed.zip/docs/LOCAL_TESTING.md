# Local testing — The Federation Universe

## Prerequisites
- Go 1.24+
- Node.js 18+
- npm

## 1. Build the game client
From `public/mud-client`:

```powershell
npm install
npm run build
```

A successful build prints `Copied mud-client build to .../pkg/webuiplay/dist`.

## 2. Seed the development world
From the repository root:

```powershell
go run .\cmd\seed_federation
```

Expected result: `The Federation Universe demo world is ready: 12 rooms, 6 NPCs`.

## 3. Start the server
In the repository root:

```powershell
go run .\cmd\tales
```

## 4. Open the game
Visit `http://localhost:8010/play`.

## 5. Verify the universe endpoint
Visit `http://localhost:8010/api/universe`.

## 6. Verify the world
Create/log into a test character and enter the seeded Horizon Station. Verify movement between rooms, room descriptions, NPC presence, and chat.

## If something fails
Copy the complete terminal output and send it back. Do not run `npm audit fix --force` while we are stabilizing the fork.
