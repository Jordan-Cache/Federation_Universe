package worldseed

import (
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/talesmud/talesmud/pkg/entities"
	npc "github.com/talesmud/talesmud/pkg/entities/npcs"
	"github.com/talesmud/talesmud/pkg/entities/rooms"
	"github.com/talesmud/talesmud/pkg/entities/traits"
	"github.com/talesmud/talesmud/pkg/repository"
)

// SeedFederationDemo creates the first playable Federation Universe environment.
// It is deliberately small and idempotent so it can be used repeatedly during development.
func SeedFederationDemo(repos repository.Factory) (int, int, error) {
	roomsRepo := repos.Rooms()
	npcsRepo := repos.NPCs()

	existing, err := roomsRepo.FindByName("Horizon Station - Main Concourse")
	if err != nil {
		return 0, 0, err
	}
	if len(existing) > 0 {
		npcs, err := npcsRepo.FindAll()
		if err != nil {
			return 0, 0, err
		}
		return len(existing), len(npcs), nil
	}

	now := time.Now().UTC()
	stationID := uuid.NewString()
	stationName := "Horizon Station"
	roomsByKey := make(map[string]*rooms.Room)

	definitions := []struct {
		key, name, description, area string
	}{
		{"concourse", "Horizon Station - Main Concourse", "A broad Federation starbase concourse filled with personnel, travelers, cargo handlers, and the low hum of station operations.", stationName},
		{"ops", "Operations Center", "A command-and-control center overlooking the station's primary traffic and communications systems.", stationName},
		{"transporter", "Transporter Room", "A transporter chamber with two active platforms and a control console linked to station operations.", stationName},
		{"sickbay", "Sickbay", "A clean, bright medical facility staffed around the clock by medical personnel.", stationName},
		{"science", "Science Laboratory", "A multi-purpose science laboratory filled with sensor consoles and analytical equipment.", stationName},
		{"engineering", "Engineering", "A high-energy engineering deck surrounding the station's primary power and systems control equipment.", stationName},
		{"quarters", "Crew Quarters", "Residential quarters for station personnel and visiting crews.", stationName},
		{"mess", "Crew Mess", "A busy dining facility where crews from dozens of departments gather between shifts.", stationName},
		{"security", "Security Office", "The station security office, with evidence lockers, monitoring stations, and a secure briefing room.", stationName},
		{"docking", "Docking Control", "A large operations chamber coordinating traffic through the station's docking facilities.", stationName},
		{"promenade", "Promenade", "A commercial promenade with civilian shops, services, food vendors, and visitors from across the sector.", stationName},
		{"airlock", "Shuttle Bay", "A pressurized shuttle bay containing landing craft, maintenance equipment, and flight-control stations.", stationName},
	}

	for _, d := range definitions {
		room := &rooms.Room{
			Entity:               entities.NewEntity(),
			Name:                 d.name,
			Description:          d.description,
			Detail:               d.description,
			RoomType:             "starbase",
			UniverseLocationID:   stationID,
			UniverseLocationType: "room",
			UniverseParentID:     stationID,
			Area:                 d.area,
			AreaType:             "starbase",
			Tags:                 []string{"federation-universe", "starbase", "horizon-station", "phase-1"},
			Actions:              &rooms.Actions{},
			Exits:                &rooms.Exits{},
			Characters:           &rooms.Characters{},
			NPCs:                 &rooms.NPCs{},
			Items:                &rooms.Items{},
			CanBind:              true,
		}
		if room.Meta == nil {
			room.Meta = &struct {
				Mood       string `bson:"mood,omitempty" json:"mood,omitempty"`
				Background string `bson:"background,omitempty" json:"background,omitempty"`
			}{Mood: "active", Background: "federation-starbase"}
		}
		// Encode the future universe hierarchy into room tags until the dedicated
		// universe repository arrives in a later phase.
		room.Tags = append(room.Tags, "station:"+stationID)
		if _, err := roomsRepo.Store(room); err != nil {
			return 0, 0, fmt.Errorf("store room %q: %w", d.name, err)
		}
		roomsByKey[d.key] = room
	}

	connect := func(a, exitName, b string) error {
		from := roomsByKey[a]
		to := roomsByKey[b]
		*from.Exits = append(*from.Exits, rooms.Exit{Name: exitName, Type: rooms.RoomExitTypeNormal, Target: to.ID})
		return roomsRepo.Update(from.ID, from)
	}

	links := [][3]string{
		{"concourse", "operations", "ops"}, {"concourse", "transporter", "transporter"},
		{"concourse", "medical", "sickbay"}, {"concourse", "science", "science"},
		{"concourse", "engineering", "engineering"}, {"concourse", "quarters", "quarters"},
		{"concourse", "mess", "mess"}, {"concourse", "security", "security"},
		{"concourse", "docking", "docking"}, {"concourse", "promenade", "promenade"},
		{"concourse", "shuttlebay", "airlock"},
	}
	for _, link := range links {
		if err := connect(link[0], link[1], link[2]); err != nil {
			return 0, 0, err
		}
	}

	npcDefs := []struct {
		name, description, roomKey, rank, department, occupation string
	}{
		{"Commander T'Varen", "A calm Vulcan operations officer supervising traffic and station coordination.", "ops", "Commander", "Operations", "Operations Officer"},
		{"Lieutenant Mara Chen", "A senior human science officer reviewing sensor data from the outer sector.", "science", "Lieutenant", "Science", "Science Officer"},
		{"Doctor Elias Venn", "The station physician, currently reviewing medical reports from the last duty shift.", "sickbay", "Commander", "Medical", "Chief Medical Officer"},
		{"Chief Ralvek", "A Tellarite chief engineer with a reputation for solving impossible engineering problems.", "engineering", "Lieutenant Commander", "Engineering", "Chief Engineer"},
		{"Ensign Kira Sol", "A young security officer monitoring the station's internal sensor network.", "security", "Ensign", "Security", "Security Officer"},
		{"Sera Dax", "A civilian merchant operating a small import business on the station promenade.", "promenade", "Civilian", "Civilian", "Merchant"},
	}

	npcCount := 0
	for _, d := range npcDefs {
		room := roomsByKey[d.roomKey]
		n := &npc.NPC{
			Entity:           entities.NewEntity(),
			Name:             d.name,
			Description:      d.description,
			CurrentRoom:      traits.CurrentRoom{CurrentRoomID: room.ID},
			CurrentHitPoints: 100,
			MaxHitPoints:     100,
			Level:            1,
			IsTemplate:       false,
			SpawnRoomID:      room.ID,
			State:            "idle",
			Created:          now,
			Updated:          now,
		}
		if _, err := npcsRepo.Import(n); err != nil {
			return len(roomsByKey), npcCount, fmt.Errorf("store npc %q: %w", d.name, err)
		}
		*room.NPCs = append(*room.NPCs, n.ID)
		if err := roomsRepo.Update(room.ID, room); err != nil {
			return len(roomsByKey), npcCount, err
		}
		npcCount++
		_ = d.rank
		_ = d.department
		_ = d.occupation
	}

	return len(roomsByKey), npcCount, nil
}
