package universe

import (
	"testing"
	"time"
)

func TestDefaultConfig(t *testing.T) {
	cfg := DefaultConfig()
	if cfg.UniverseName != Name || cfg.Setting != Setting {
		t.Fatalf("unexpected universe identity: %+v", cfg)
	}
	if !cfg.ContinueOffline || !cfg.EnablePersistentClock || !cfg.EnableRealtimePresence {
		t.Fatalf("phase 1 persistence/realtime defaults are not enabled: %+v", cfg)
	}
}

func TestClockAdvance(t *testing.T) {
	start := time.Date(2380, 1, 1, 12, 0, 0, 0, time.UTC)
	clock := NewClock(start)
	clock.TimeScale = 60
	got := clock.Advance(2 * time.Second)
	want := start.Add(2 * time.Minute)
	if !got.Equal(want) {
		t.Fatalf("clock advanced to %s, want %s", got, want)
	}
}

func TestShipValidation(t *testing.T) {
	ship := NewShip("USS Resolute", "NCC-90001", "Exploration Cruiser", "federation")
	if err := ship.Validate(); err != nil {
		t.Fatalf("new ship should validate: %v", err)
	}
	ship.HullIntegrity = 101
	if err := ship.Validate(); err == nil {
		t.Fatal("expected invalid hull integrity to fail validation")
	}
}
