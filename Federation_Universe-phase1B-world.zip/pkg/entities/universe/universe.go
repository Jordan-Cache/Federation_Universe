// Package universe contains the persistent-world domain model for The Federation Universe.
//
// It intentionally stays independent from the existing TalesMUD fantasy gameplay systems.
// This lets us progressively replace those systems without throwing away the mature
// networking, persistence, scripting, and editor infrastructure we are inheriting.
package universe

import (
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
)

const (
	Name    = "The Federation Universe"
	Setting = "Star Trek homebrew / custom universe"
	Version = "0.1.0-phase1"
)

// LocationType describes where an entity exists in the universe hierarchy.
type LocationType string

const (
	LocationQuadrant   LocationType = "quadrant"
	LocationSector     LocationType = "sector"
	LocationStarSystem LocationType = "star_system"
	LocationCelestial  LocationType = "celestial_body"
	LocationStation    LocationType = "station"
	LocationShip       LocationType = "ship"
	LocationDeck       LocationType = "deck"
	LocationRoom       LocationType = "room"
)

// Location is a persistent node in the Federation Universe spatial hierarchy.
type Location struct {
	ID          string       `json:"id"`
	ParentID    string       `json:"parentId,omitempty"`
	Type        LocationType `json:"type"`
	Name        string       `json:"name"`
	Description string       `json:"description,omitempty"`
	Tags        []string     `json:"tags,omitempty"`
}

func NewLocation(name string, locationType LocationType, parentID string) *Location {
	return &Location{
		ID:       uuid.NewString(),
		ParentID: parentID,
		Type:     locationType,
		Name:     strings.TrimSpace(name),
	}
}

// StarSystem represents a named stellar system and its persistent contents.
type StarSystem struct {
	ID          string   `json:"id"`
	Name        string   `json:"name"`
	SectorID    string   `json:"sectorId,omitempty"`
	Description string   `json:"description,omitempty"`
	Tags        []string `json:"tags,omitempty"`
}

func NewStarSystem(name, sectorID string) *StarSystem {
	return &StarSystem{ID: uuid.NewString(), Name: strings.TrimSpace(name), SectorID: sectorID}
}

// Ship is the first-class representation of a vessel. Interior rooms will reference
// the ship ID, allowing ships to move through space without rebuilding their interiors.
type Ship struct {
	ID              string  `json:"id"`
	Registry        string  `json:"registry"`
	Name            string  `json:"name"`
	Class           string  `json:"class,omitempty"`
	FactionID       string  `json:"factionId,omitempty"`
	CurrentLocation string  `json:"currentLocation,omitempty"`
	HullIntegrity   float64 `json:"hullIntegrity"`
	ShieldIntegrity float64 `json:"shieldIntegrity"`
	AlertStatus     string  `json:"alertStatus"`
	CrewCapacity    int     `json:"crewCapacity"`
	Active          bool    `json:"active"`
}

func NewShip(name, registry, shipClass, factionID string) *Ship {
	return &Ship{
		ID:              uuid.NewString(),
		Name:            strings.TrimSpace(name),
		Registry:        strings.TrimSpace(registry),
		Class:           strings.TrimSpace(shipClass),
		FactionID:       factionID,
		HullIntegrity:   100,
		ShieldIntegrity: 100,
		AlertStatus:     "normal",
		Active:          true,
	}
}

// Faction represents any persistent political, military, commercial, cultural,
// criminal, or other organization in the homebrew universe.
type Faction struct {
	ID          string   `json:"id"`
	Name        string   `json:"name"`
	Description string   `json:"description,omitempty"`
	Government  string   `json:"government,omitempty"`
	Tags        []string `json:"tags,omitempty"`
}

func NewFaction(name string) *Faction {
	return &Faction{ID: uuid.NewString(), Name: strings.TrimSpace(name)}
}

// Clock describes the server's persistent universe clock. The simulation is designed
// to continue advancing even when no players are connected.
type Clock struct {
	StartedAt       time.Time `json:"startedAt"`
	CurrentTime     time.Time `json:"currentTime"`
	TimeScale       float64   `json:"timeScale"`
	ContinueOffline bool      `json:"continueOffline"`
}

func NewClock(now time.Time) *Clock {
	return &Clock{
		StartedAt:       now.UTC(),
		CurrentTime:     now.UTC(),
		TimeScale:       1,
		ContinueOffline: true,
	}
}

func (c *Clock) Advance(realElapsed time.Duration) time.Time {
	if c == nil {
		return time.Time{}
	}
	if c.TimeScale <= 0 {
		return c.CurrentTime
	}
	c.CurrentTime = c.CurrentTime.Add(time.Duration(float64(realElapsed) * c.TimeScale))
	return c.CurrentTime
}

// Config centralizes the foundational simulation switches so later phases can evolve
// the engine without scattering Star Trek-specific assumptions through server code.
type Config struct {
	UniverseName           string `json:"universeName"`
	Setting                string `json:"setting"`
	EnablePersistentClock  bool   `json:"enablePersistentClock"`
	ContinueOffline        bool   `json:"continueOffline"`
	EnableRealtimePresence bool   `json:"enableRealtimePresence"`
	EnableNPCSimulation    bool   `json:"enableNPCSimulation"`
	EnableDynamicEvents    bool   `json:"enableDynamicEvents"`
}

func DefaultConfig() Config {
	return Config{
		UniverseName:           Name,
		Setting:                Setting,
		EnablePersistentClock:  true,
		ContinueOffline:        true,
		EnableRealtimePresence: true,
		EnableNPCSimulation:    true,
		EnableDynamicEvents:    false, // enabled when Phase 2 simulation is ready
	}
}

func (s Ship) Validate() error {
	if strings.TrimSpace(s.Name) == "" {
		return fmt.Errorf("ship name is required")
	}
	if strings.TrimSpace(s.Registry) == "" {
		return fmt.Errorf("ship registry is required")
	}
	if s.HullIntegrity < 0 || s.HullIntegrity > 100 {
		return fmt.Errorf("hull integrity must be between 0 and 100")
	}
	if s.ShieldIntegrity < 0 || s.ShieldIntegrity > 100 {
		return fmt.Errorf("shield integrity must be between 0 and 100")
	}
	return nil
}
