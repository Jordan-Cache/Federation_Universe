package characters

import "github.com/talesmud/talesmud/pkg/entities/items"

// SystemCharacterTemplatePresets returns a hardcoded list of templates that can be seeded into the database.
// These are intended as "starter defaults" and can be modified after import.
func SystemCharacterTemplatePresets() []*CharacterTemplate {
	return []*CharacterTemplate{
		federationTemplate("Starfleet Command", "Command-track officer prepared to lead a starship or station department.", "command", "Captain", "Command", "Starfleet Officer"),
		federationTemplate("Starfleet Operations", "Operations and engineering-oriented officer responsible for ship systems, logistics, and infrastructure.", "operations", "Lieutenant", "Operations", "Operations Officer"),
		federationTemplate("Starfleet Science", "Science-track officer focused on exploration, research, sensors, and anomaly investigation.", "science", "Lieutenant", "Science", "Science Officer"),
		federationTemplate("Starfleet Medical", "Medical professional assigned to shipboard or planetary medical operations.", "medical", "Lieutenant", "Medical", "Medical Officer"),
		federationTemplate("Starfleet Security", "Security and tactical specialist responsible for personnel safety and tactical readiness.", "security", "Lieutenant", "Security", "Security Officer"),
		federationTemplate("Independent Explorer", "Civilian or independent spacer who makes a living exploring the Federation Universe beyond formal Starfleet service.", "civilian", "Civilian", "Independent", "Independent Explorer"),
	}
}

func federationTemplate(name, description, archetype, rank, department, occupation string) *CharacterTemplate {
	return &CharacterTemplate{
		Entity:            nil,
		Name:              name,
		Description:       description,
		Backstory:         "A citizen of The Federation Universe beginning a new chapter among the stars.",
		OriginArea:        "Unspecified",
		Archetype:         archetype,
		Species:           "Human",
		Pronouns:          "They/Them",
		Rank:              rank,
		Department:        department,
		Occupation:        occupation,
		FactionID:         "federation",
		CurrentAssignment: "Unassigned",
		Race:              RaceHuman,
		Class:             Class{ID: archetype, Name: occupation, Description: description},
		Level:             1,
		CurrentHitPoints:  100,
		MaxHitPoints:      100,
		Attributes:        createBaseAttributes(10, 10, 10, 10, 10),
		Source:            "system",
	}
}
