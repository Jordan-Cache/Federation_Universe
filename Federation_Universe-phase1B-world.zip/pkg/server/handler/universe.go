package handler

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/talesmud/talesmud/pkg/entities/universe"
)

// UniverseHandler exposes the small public manifest used by clients to identify the
// active game universe. Detailed world data remains behind the normal game APIs.
type UniverseHandler struct{}

func (h *UniverseHandler) GetManifest(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"name":    universe.Name,
		"setting": universe.Setting,
		"version": universe.Version,
		"config":  universe.DefaultConfig(),
		"phase":   1,
		"status":  "foundation",
	})
}
