package dto

// CreateCharacterDTO ...
type CreateCharacterDTO struct {
	TemplateID        string `json:"templateId"`
	Name              string `json:"name"`
	Description       string `json:"description"`
	Species           string `json:"species,omitempty"`
	Pronouns          string `json:"pronouns,omitempty"`
	Rank              string `json:"rank,omitempty"`
	Department        string `json:"department,omitempty"`
	Occupation        string `json:"occupation,omitempty"`
	FactionID         string `json:"factionId,omitempty"`
	CurrentAssignment string `json:"currentAssignment,omitempty"`
	HomeLocationID    string `json:"homeLocationId,omitempty"`
	CurrentLocationID string `json:"currentLocationId,omitempty"`
	UserID            string
}
