# The Federation Universe — Phase 1A Character System

This pass moves character creation from fantasy RPG assumptions toward the Star Trek homebrew setting.

## Added

- Federation Universe profile fields on character templates and characters:
  - Species
  - Pronouns
  - Rank / status
  - Department
  - Occupation
  - Faction
  - Current assignment
  - Home/current location IDs
- Six initial system character paths:
  - Starfleet Command
  - Starfleet Operations
  - Starfleet Science
  - Starfleet Medical
  - Starfleet Security
  - Independent Explorer
- Character creation API accepts and persists the Federation profile fields.
- Character creation wizard now asks for Federation identity and career information.
- Fantasy names such as Warrior/Rogue/Mage are no longer presented by the system character templates.

## Compatibility

Legacy Race/Class fields remain internally for now so existing TalesMUD gameplay code and stored data do not break while the migration continues. They are no longer the intended player-facing character model.

## Next

The next character pass should introduce richer species/faction/organization registries, qualifications, career progression, assignments, and location binding.
