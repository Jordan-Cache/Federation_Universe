# The Federation Universe — Phase 1 Foundation

The Federation Universe is a persistent, 24/7, real-time text roleplay game set in a Star Trek homebrew/custom universe.

## Architecture principle

TalesMUD is the inherited engine foundation, not the final game design. Existing networking, WebSockets, persistence, scripting, NPC/dialog infrastructure, and creator tools are retained where useful while fantasy-specific gameplay is progressively replaced.

## Phase 1 domain model

The new `pkg/entities/universe` package establishes a neutral persistent-world hierarchy:

- Quadrant
- Sector
- Star system
- Celestial body
- Station
- Ship
- Deck
- Room

Ships are first-class entities. Their interiors can remain persistent while their exterior location changes. Factions are also first-class entities so Federation, governments, corporations, crews, criminal groups, and other organizations can use the same underlying system.

## Persistent simulation

The universe has a persistent clock with configurable time scale. The intended behavior is that world time continues to advance even when no players are connected. NPC simulation and dynamic events are separate switches so they can be enabled only after their respective systems are ready.

## Character migration

The legacy fantasy `Race` and `Class` fields remain temporarily for backwards compatibility. Federation Universe profile fields have been added alongside them:

- Species
- Pronouns
- Rank
- Department
- Occupation
- Faction
- Current assignment
- Home location
- Current location

The next character-system milestone will migrate the UI and gameplay away from fantasy classes/races instead of deleting legacy data abruptly.

## Public universe manifest

`GET /api/universe` identifies the running installation as The Federation Universe and exposes the Phase 1 configuration flags to the client.

## Phase 1 completion target

A player should eventually be able to create a Federation Universe character, enter a persistent starbase/ship environment, move between rooms in real time, see other players, communicate locally, and return later to find the universe clock advanced.
