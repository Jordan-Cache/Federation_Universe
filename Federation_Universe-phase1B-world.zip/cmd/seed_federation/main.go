// Command seed_federation creates the first playable Federation Universe test world.
package main

import (
	"fmt"
	"os"

	log "github.com/sirupsen/logrus"
	dbsqlite "github.com/talesmud/talesmud/pkg/db/sqlite"
	"github.com/talesmud/talesmud/pkg/repository"
	"github.com/talesmud/talesmud/pkg/worldseed"
)

func main() {
	path := os.Getenv("SQLITE_PATH")
	if path == "" {
		path = "talesmud.db"
	}
	client, err := dbsqlite.Open(path)
	if err != nil {
		log.WithError(err).Fatal("failed to open database")
	}
	defer client.Close()

	repos := repository.NewSQLiteFactory(client)
	roomCount, npcCount, err := worldseed.SeedFederationDemo(repos)
	if err != nil {
		log.WithError(err).Fatal("failed to seed Federation Universe demo world")
	}
	fmt.Printf("The Federation Universe demo world is ready: %d rooms, %d NPCs\n", roomCount, npcCount)
}
