# The Federation Universe — Phase 1B World Foundation

Phase 1B establishes the first playable homebrew Star Trek environment: **Horizon Station**.

## Seeded environment

The development seed creates 12 connected rooms:

- Horizon Station - Main Concourse
- Operations Center
- Transporter Room
- Sickbay
- Science Laboratory
- Engineering
- Crew Quarters
- Crew Mess
- Security Office
- Docking Control
- Promenade
- Shuttle Bay

It also creates six persistent NPCs positioned in their departments.

## Important design choice

Horizon Station is original homebrew content. No canon location, ship, character, or faction is required by this seed.

The existing TalesMUD room engine remains the live multiplayer spatial layer. Federation Universe metadata is attached to rooms so we can later replace this bridge with a dedicated universe repository without rewriting the realtime gameplay system.

## Seed command

From the repository root:

```bash
go run ./cmd/seed_federation
```

Set `SQLITE_PATH` if using a different database path.
