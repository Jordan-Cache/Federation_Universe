package worldseed

import (
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/talesmud/talesmud/pkg/entities"
	"github.com/talesmud/talesmud/pkg/entities/characters"
	npc "github.com/talesmud/talesmud/pkg/entities/npcs"
	"github.com/talesmud/talesmud/pkg/entities/rooms"
	"github.com/talesmud/talesmud/pkg/entities/traits"
	"github.com/talesmud/talesmud/pkg/repository"
)

// SeedHorizonStation creates the first original Federation Universe location.
// It is a development seed and replaces only rooms/NPCs in the development DB.
func SeedHorizonStation(repos repository.Factory) (int, int, error) {
	if err := repos.Rooms().Drop(); err != nil {
		return 0, 0, fmt.Errorf("drop rooms: %w", err)
	}
	if err := repos.NPCs().Drop(); err != nil {
		return 0, 0, fmt.Errorf("drop npcs: %w", err)
	}

	stationID := uuid.NewString()
	roomIDs := map[string]string{}
	specs := []struct{ key, name, desc string }{
		{"concourse", "Horizon Station - Main Concourse", "The broad central concourse of Horizon Station. Federation signage, duty rosters and arrivals displays glow above the traffic lanes."},
		{"operations", "Operations Center", "A circular operations center overlooking the station's primary traffic-control systems."},
		{"transporter", "Transporter Room", "A clean transporter chamber with paired bio-scanners and a shimmering pattern buffer."},
		{"sickbay", "Sickbay", "A compact but fully equipped medical facility staffed around the clock."},
		{"science", "Science Laboratory", "A multi-purpose laboratory filled with sensor consoles and specimen containment equipment."},
		{"engineering", "Engineering", "Power conduits, diagnostic stations and the steady thrum of the station's reactor dominate the room."},
		{"quarters", "Crew Quarters", "Modular living quarters for officers and station personnel."},
		{"mess", "Crew Mess", "A comfortable communal dining hall with replicators and long observation windows."},
		{"security", "Security Office", "The station security office, with evidence lockers and a tactical operations console."},
		{"docking", "Docking Control", "Traffic control for visiting ships, shuttles and cargo craft."},
		{"promenade", "Promenade", "A busy civilian promenade lined with small shops, services and gathering spaces."},
		{"shuttle", "Shuttle Bay", "A pressurized shuttle bay with maintenance gantries and a view of the stars beyond the forcefield."},
	}
	for _, sp := range specs {
		r := &rooms.Room{
			Entity: entities.NewEntity(), Name: sp.name, Description: sp.desc, RoomType: "station",
			Area: "Horizon Station", AreaType: "starbase", Tags: []string{"federation-universe", "horizon-station"},
			UniverseLocationID: stationID, UniverseLocationType: "room", UniverseParentID: stationID,
			LookAt: traits.LookAt{Detail: sp.desc}, Exits: &rooms.Exits{}, Characters: &rooms.Characters{}, NPCs: &rooms.NPCs{},
		}
		roomIDs[sp.key] = r.ID
		if _, err := repos.Rooms().Store(r); err != nil {
			return 0, 0, fmt.Errorf("store room %s: %w", sp.name, err)
		}
	}

	links := map[string][]rooms.Exit{
		"concourse":   {{Name: "operations", Type: rooms.RoomExitTypeNormal, Target: roomIDs["operations"]}, {Name: "promenade", Type: rooms.RoomExitTypeNormal, Target: roomIDs["promenade"]}, {Name: "security", Type: rooms.RoomExitTypeNormal, Target: roomIDs["security"]}, {Name: "transporter", Type: rooms.RoomExitTypeNormal, Target: roomIDs["transporter"]}},
		"operations":  {{Name: "concourse", Type: rooms.RoomExitTypeNormal, Target: roomIDs["concourse"]}, {Name: "docking", Type: rooms.RoomExitTypeNormal, Target: roomIDs["docking"]}},
		"transporter": {{Name: "concourse", Type: rooms.RoomExitTypeNormal, Target: roomIDs["concourse"]}, {Name: "sickbay", Type: rooms.RoomExitTypeNormal, Target: roomIDs["sickbay"]}},
		"sickbay":     {{Name: "transporter", Type: rooms.RoomExitTypeNormal, Target: roomIDs["transporter"]}, {Name: "science", Type: rooms.RoomExitTypeNormal, Target: roomIDs["science"]}},
		"science":     {{Name: "sickbay", Type: rooms.RoomExitTypeNormal, Target: roomIDs["sickbay"]}, {Name: "engineering", Type: rooms.RoomExitTypeNormal, Target: roomIDs["engineering"]}},
		"engineering": {{Name: "science", Type: rooms.RoomExitTypeNormal, Target: roomIDs["science"]}, {Name: "quarters", Type: rooms.RoomExitTypeNormal, Target: roomIDs["quarters"]}, {Name: "shuttle", Type: rooms.RoomExitTypeNormal, Target: roomIDs["shuttle"]}},
		"quarters":    {{Name: "engineering", Type: rooms.RoomExitTypeNormal, Target: roomIDs["engineering"]}, {Name: "mess", Type: rooms.RoomExitTypeNormal, Target: roomIDs["mess"]}},
		"mess":        {{Name: "quarters", Type: rooms.RoomExitTypeNormal, Target: roomIDs["quarters"]}, {Name: "promenade", Type: rooms.RoomExitTypeNormal, Target: roomIDs["promenade"]}},
		"security":    {{Name: "concourse", Type: rooms.RoomExitTypeNormal, Target: roomIDs["concourse"]}, {Name: "promenade", Type: rooms.RoomExitTypeNormal, Target: roomIDs["promenade"]}},
		"docking":     {{Name: "operations", Type: rooms.RoomExitTypeNormal, Target: roomIDs["operations"]}, {Name: "shuttle", Type: rooms.RoomExitTypeNormal, Target: roomIDs["shuttle"]}},
		"promenade":   {{Name: "concourse", Type: rooms.RoomExitTypeNormal, Target: roomIDs["concourse"]}, {Name: "security", Type: rooms.RoomExitTypeNormal, Target: roomIDs["security"]}, {Name: "mess", Type: rooms.RoomExitTypeNormal, Target: roomIDs["mess"]}},
		"shuttle":     {{Name: "engineering", Type: rooms.RoomExitTypeNormal, Target: roomIDs["engineering"]}, {Name: "docking", Type: rooms.RoomExitTypeNormal, Target: roomIDs["docking"]}},
	}
	for key, exits := range links {
		r, err := repos.Rooms().FindByID(roomIDs[key])
		if err != nil {
			return 0, 0, err
		}
		r.Exits = &rooms.Exits{}
		*r.Exits = exits
		if err := repos.Rooms().Update(r.ID, r); err != nil {
			return 0, 0, fmt.Errorf("update exits %s: %w", r.Name, err)
		}
	}

	npcSpecs := []struct{ name, desc, room string }{
		{"Commander T'Varen", "A calm Vulcan station commander reviewing operations reports.", "operations"},
		{"Lieutenant Mara Chen", "A Federation science officer cataloguing sensor anomalies.", "science"},
		{"Doctor Elias Venn", "A physician checking a medical console and monitoring patients.", "sickbay"},
		{"Chief Ralvek", "The station's Andorian chief engineer, grease-stained and focused on a diagnostic display.", "engineering"},
		{"Ensign Kira Sol", "A young security officer maintaining a watch on the promenade.", "security"},
		{"Sera Dax", "A civilian merchant running a small storefront on the promenade.", "promenade"},
	}
	for _, sp := range npcSpecs {
		n := &npc.NPC{
			Entity: entities.NewEntity(), Name: sp.name, Description: sp.desc, Race: characters.RaceHuman,
			Class: characters.ClassWarrior, Level: 1, CurrentHitPoints: 100, MaxHitPoints: 100,
			IsTemplate: false, SpawnRoomID: roomIDs[sp.room], CurrentRoom: traits.CurrentRoom{CurrentRoomID: roomIDs[sp.room]},
			State: "idle", Created: time.Now(), Updated: time.Now(),
		}
		stored, err := repos.NPCs().Store(n)
		if err != nil {
			return 0, 0, fmt.Errorf("store npc %s: %w", sp.name, err)
		}
		r, err := repos.Rooms().FindByID(roomIDs[sp.room])
		if err != nil {
			return 0, 0, err
		}
		if r.NPCs == nil {
			r.NPCs = &rooms.NPCs{}
		}
		*r.NPCs = append(*r.NPCs, stored.ID)
		if err := repos.Rooms().Update(r.ID, r); err != nil {
			return 0, 0, fmt.Errorf("place npc %s: %w", sp.name, err)
		}
	}
	return len(specs), len(npcSpecs), nil
}
