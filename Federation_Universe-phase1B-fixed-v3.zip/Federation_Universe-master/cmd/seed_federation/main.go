package main

import (
	"flag"
	"fmt"
	"log"

	dbsqlite "github.com/talesmud/talesmud/pkg/db/sqlite"
	"github.com/talesmud/talesmud/pkg/repository"
	"github.com/talesmud/talesmud/pkg/worldseed"
)

func main() {
	sqlitePath := flag.String("sqlite", "talesmud.db", "SQLite database path")
	flag.Parse()
	client, err := dbsqlite.Open(*sqlitePath)
	if err != nil {
		log.Fatal(err)
	}
	defer client.Close()
	repos := repository.NewSQLiteFactory(client)
	rooms, npcs, err := worldseed.SeedHorizonStation(repos)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("The Federation Universe demo world is ready: %d rooms, %d NPCs\n", rooms, npcs)
}
