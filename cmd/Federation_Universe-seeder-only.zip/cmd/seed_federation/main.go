// Command seed_federation creates the first playable Federation Universe development world.
package main

import (
	"fmt"
	"os"
	"time"

	"github.com/talesmud/talesmud/pkg/db/sqlite"
	"github.com/talesmud/talesmud/pkg/entities"
	npc "github.com/talesmud/talesmud/pkg/entities/npcs"
	"github.com/talesmud/talesmud/pkg/entities/rooms"
	"github.com/talesmud/talesmud/pkg/entities/traits"
	"github.com/talesmud/talesmud/pkg/repository"
)

func main() {
	path := os.Getenv("SQLITE_PATH")
	if path == "" {
		path = "talesmud.db"
	}

	client, err := sqlite.Open(path)
	if err != nil {
		panic(fmt.Errorf("open database: %w", err))
	}
	defer client.Close()

	repos := repository.NewSQLiteFactory(client)
	roomsRepo := repos.Rooms()
	npcsRepo := repos.NPCs()

	const concourse = "Horizon Station - Main Concourse"
	existing, err := roomsRepo.FindByName(concourse)
	if err != nil {
		panic(fmt.Errorf("check existing world: %w", err))
	}
	if len(existing) > 0 {
		fmt.Println("Horizon Station is already seeded. Nothing to do.")
		return
	}

	type roomDef struct{ key, name, description string }
	defs := []roomDef{
		{"concourse", concourse, "The main concourse of Horizon Station. Starfleet officers, civilians, traders, and visitors move through the station around the clock."},
		{"operations", "Operations Center", "A command center coordinating station traffic, communications, and daily operations."},
		{"transporter", "Transporter Room", "A transporter facility with active platforms and a control console."},
		{"sickbay", "Sickbay", "The station medical facility, staffed around the clock."},
		{"science", "Science Laboratory", "A multi-purpose laboratory filled with sensor and analysis equipment."},
		{"engineering", "Engineering", "A high-energy engineering deck surrounding the station's primary systems."},
		{"quarters", "Crew Quarters", "Residential quarters for station personnel and visiting crews."},
		{"mess", "Crew Mess", "A busy dining facility where crews gather between shifts."},
		{"security", "Security Office", "Station security headquarters and monitoring center."},
		{"docking", "Docking Control", "Traffic control for vessels arriving at and departing from Horizon Station."},
		{"promenade", "Promenade", "A civilian commercial district with shops, services, food vendors, and visitors."},
		{"shuttle", "Shuttle Bay", "A pressurized shuttle bay containing craft, maintenance equipment, and flight-control stations."},
	}

	byKey := make(map[string]*rooms.Room, len(defs))
	for _, d := range defs {
		r := &rooms.Room{
			Entity:      entities.NewEntity(),
			Name:        d.name,
			Description: d.description,
			RoomType:    "starbase",
			Area:        "Horizon Station",
			AreaType:    "starbase",
			Tags:        []string{"federation-universe", "horizon-station", "homebrew", "phase-1b"},
			Actions:     &rooms.Actions{},
			Exits:       &rooms.Exits{},
			Characters:  &rooms.Characters{},
			NPCs:        &rooms.NPCs{},
			Items:       &rooms.Items{},
			CanBind:     true,
			Meta: &struct {
				Mood       string `bson:"mood,omitempty" json:"mood,omitempty"`
				Background string `bson:"background,omitempty" json:"background,omitempty"`
			}{Mood: "active", Background: "federation-starbase"},
		}
		if _, err := roomsRepo.Store(r); err != nil {
			panic(fmt.Errorf("create room %q: %w", d.name, err))
		}
		byKey[d.key] = r
	}

	links := [][3]string{
		{"concourse", "operations", "operations"}, {"concourse", "transporter", "transporter"},
		{"concourse", "medical", "sickbay"}, {"concourse", "science", "science"},
		{"concourse", "engineering", "engineering"}, {"concourse", "quarters", "quarters"},
		{"concourse", "mess", "mess"}, {"concourse", "security", "security"},
		{"concourse", "docking", "docking"}, {"concourse", "promenade", "promenade"},
		{"concourse", "shuttle bay", "shuttle"},
	}
	for _, l := range links {
		from, to := byKey[l[0]], byKey[l[2]]
		*from.Exits = append(*from.Exits, rooms.Exit{Name: l[1], Type: rooms.RoomExitTypeNormal, Target: to.ID})
		if _, err := roomsRepo.Update(from.ID, from); err != nil {
			panic(fmt.Errorf("connect %s to %s: %w", from.Name, to.Name, err))
		}
	}

	npcDefs := []struct{ name, description, room string }{
		{"Commander T'Varen", "A calm Vulcan operations officer supervising station traffic.", "operations"},
		{"Lieutenant Mara Chen", "A senior science officer reviewing sensor data from the outer sector.", "science"},
		{"Doctor Elias Venn", "The station physician reviewing medical reports from the last shift.", "sickbay"},
		{"Chief Ralvek", "A Tellarite chief engineer known for solving difficult systems problems.", "engineering"},
		{"Ensign Kira Sol", "A security officer monitoring the station's internal sensor network.", "security"},
		{"Sera Dax", "A civilian merchant operating an import business on the promenade.", "promenade"},
	}

	for _, d := range npcDefs {
		r := byKey[d.room]
		n := &npc.NPC{
			Entity:           entities.NewEntity(),
			CurrentRoom:      traits.CurrentRoom{CurrentRoomID: r.ID},
			Name:             d.name,
			Description:      d.description,
			CurrentHitPoints: 100,
			MaxHitPoints:     100,
			Level:            1,
			IsTemplate:       false,
			SpawnRoomID:      r.ID,
			State:            "idle",
			Created:          time.Now().UTC(),
			Updated:          time.Now().UTC(),
		}
		if _, err := npcsRepo.Store(n); err != nil {
			panic(fmt.Errorf("create NPC %q: %w", d.name, err))
		}
		*r.NPCs = append(*r.NPCs, n.ID)
		if _, err := roomsRepo.Update(r.ID, r); err != nil {
			panic(fmt.Errorf("place NPC %q: %w", d.name, err))
		}
	}

	fmt.Printf("The Federation Universe: Horizon Station seeded successfully — %d rooms, %d NPCs.\n", len(defs), len(npcDefs))
}
